#include "ProtocalKaerServer.h"

ProtocalKaerServer::ProtocalKaerServer(QObject *parent) :
    ProtocalProcess(parent)
{
}
