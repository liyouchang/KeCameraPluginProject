#include "ChVideoFileReader.h"

ChVideoFileReader::ChVideoFileReader(QObject *parent) :
    QObject(parent)
{
}
