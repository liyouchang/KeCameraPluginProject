#ifndef CHVIDEOFILEREADER_H
#define CHVIDEOFILEREADER_H

#include <QObject>

class ChVideoFileReader : public QObject
{
    Q_OBJECT
public:
    explicit ChVideoFileReader(QObject *parent = 0);

signals:

public slots:

};

#endif // CHVIDEOFILEREADER_H
